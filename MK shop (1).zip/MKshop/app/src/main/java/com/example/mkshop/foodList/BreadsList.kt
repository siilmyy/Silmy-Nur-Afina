package com.example.mkshop.foodList

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.MainActivity
import com.example.mkshop.R
import com.example.mkshop.detail.*

class BreadsList : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.breads_list)

        //detail btn
        val rotiDetailBtn: Button = findViewById(R.id.roti_detail_btn)
        val rotiIsiDetailBtn : Button = findViewById(R.id.roti_isi_detail_btn)
        val backToHomeBtn: Button = findViewById(R.id.back_to_home)

        //detail button onclick listener
        rotiDetailBtn.setOnClickListener(){goToBreadDetail(rotiDetailBtn)}
        rotiIsiDetailBtn.setOnClickListener(){goToBreadDetail(rotiIsiDetailBtn)}
        backToHomeBtn.setOnClickListener(){goToHome(backToHomeBtn)}
    }

    fun goToBreadDetail(v: View) {
        when (v.id) {
            R.id.roti_detail_btn -> {
                val rotiDetailIntent = Intent(this@BreadsList, RotiDetail::class.java)
                startActivity(rotiDetailIntent)
            }
            R.id.roti_isi_detail_btn -> {
                val rotiIsiDetailIntent = Intent(this@BreadsList, RotiIsiDetail::class.java)
                startActivity(rotiIsiDetailIntent)
            }

        }
    }
    private fun goToHome(v: View) {
        when (v.id) {
            R.id.back_to_home -> {
                val backToHomeIntent = Intent(this@BreadsList, MainActivity::class.java)
                startActivity(backToHomeIntent)
            }
        }
    }
}