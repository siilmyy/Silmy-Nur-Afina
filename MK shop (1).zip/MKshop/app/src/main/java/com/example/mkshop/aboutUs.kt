package com.example.mkshop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class aboutUs : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_us)
    }
}