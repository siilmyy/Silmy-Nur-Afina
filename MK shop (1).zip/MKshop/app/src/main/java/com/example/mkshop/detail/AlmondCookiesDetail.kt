package com.example.mkshop.detail

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.checkout.CheckoutCookies
import com.example.mkshop.R

class AlmondCookiesDetail : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cookies_item_almond)

        val buyNow : Button = findViewById(R.id.buy_now)
        buyNow.setOnClickListener(){goToBayar(buyNow)}
    }

    private fun goToBayar(v: View) {
        when (v.id) {
            R.id.buy_now -> {
                val checkoutCookiesIntent = Intent(this@AlmondCookiesDetail, CheckoutCookies::class.java)
                startActivity(checkoutCookiesIntent)
            }
        }
    }
}