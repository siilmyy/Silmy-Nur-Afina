package com.example.mkshop

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.example.mkshop.detail.IcecreamDetail
import com.example.mkshop.foodList.BreadsList
import com.example.mkshop.foodList.CakeList
import com.example.mkshop.foodList.CookiesList
import com.example.mkshop.foodList.IcecreamList

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //btn menu makanan
        val cakesBtn: Button = findViewById(R.id.cakes)
        val cookiesBtn: Button = findViewById(R.id.cookies)
        val breadsBtn: Button = findViewById(R.id.breads)
        val iceCreamBtn: Button = findViewById(R.id.icecream)

        //about us btn
        val aboutUs: Button = findViewById(R.id.about_us)

        //btn onclick listener
        cakesBtn.setOnClickListener(){goToView(cakesBtn)}
        cookiesBtn.setOnClickListener(){goToView(cookiesBtn)}
        breadsBtn.setOnClickListener(){goToView(breadsBtn)}
        iceCreamBtn.setOnClickListener(){goToView(iceCreamBtn)}
        aboutUs.setOnClickListener(){goToView(aboutUs)}
        //detail button onclick listener
    }

    fun goToView(v: View) {
        when (v.id) {
            R.id.cakes -> {
                val cakeListIntent = Intent(this@MainActivity, CakeList::class.java)
                startActivity(cakeListIntent)
            }
            R.id.cookies -> {
                val cookiesListIntent = Intent(this@MainActivity, CookiesList::class.java)
                startActivity(cookiesListIntent)
            }
            R.id.breads -> {
                val breadListDetail = Intent(this@MainActivity, BreadsList::class.java)
                startActivity(breadListDetail)
            }
            R.id.icecream -> {
                val iceCreamListDetail = Intent(this@MainActivity, IcecreamList::class.java)
                startActivity(iceCreamListDetail)
            }
            R.id.about_us -> {
                val aboutUsIntent = Intent(this@MainActivity, aboutUs::class.java)
                startActivity(aboutUsIntent)
            }

        }
    }
}