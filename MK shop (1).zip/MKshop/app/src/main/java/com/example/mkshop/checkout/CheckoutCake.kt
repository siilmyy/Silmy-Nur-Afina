package com.example.mkshop.checkout

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.R

class CheckoutCake : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cake_chocolate_checkout)

        val bayar: Button = findViewById(R.id.bayar)
        bayar.setOnClickListener(){goToCheckOutVerified(bayar)}
    }
    private fun goToCheckOutVerified(v: View) {
        when (v.id) {
            R.id.bayar -> {
                val checkoutIntent = Intent(this@CheckoutCake, CheckoutVerified::class.java)
                startActivity(checkoutIntent)
            }
        }
    }
}