package com.example.mkshop.foodList

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.MainActivity
import com.example.mkshop.R
import com.example.mkshop.detail.IcecreamDetail

class IcecreamList : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.icecream_list)

        val icecreamDetailBtn : Button = findViewById(R.id.icecream_detail_btn)
        val backToHomeBtn: Button = findViewById(R.id.back_to_home)
        backToHomeBtn.setOnClickListener(){goToHome(backToHomeBtn)}
        icecreamDetailBtn.setOnClickListener(){goToIceCreamDetail(icecreamDetailBtn)}
    }
    fun goToIceCreamDetail(v: View) {
        when (v.id) {
            R.id.icecream_detail_btn -> {
                val iceCreamDetailIntent = Intent(this@IcecreamList, IcecreamDetail::class.java)
                startActivity(iceCreamDetailIntent)
            }

        }
    }
    private fun goToHome(v: View) {
        when (v.id) {
            R.id.back_to_home -> {
                val backToHomeIntent = Intent(this@IcecreamList, MainActivity::class.java)
                startActivity(backToHomeIntent)
            }
        }
    }
}