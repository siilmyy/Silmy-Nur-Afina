package com.example.mkshop.detail

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.checkout.CheckoutIceCream
import com.example.mkshop.R

class IcecreamDetail : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.icecream_item)

        val buyNow : Button = findViewById(R.id.buy_now)
        buyNow.setOnClickListener(){goToBayar(buyNow)}
    }
    private fun goToBayar(v: View) {
        when (v.id) {
            R.id.buy_now -> {
                val checkoutBreadIntent = Intent(this@IcecreamDetail, CheckoutIceCream::class.java)
                startActivity(checkoutBreadIntent)
            }
        }
    }

}