package com.example.mkshop.foodList

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.MainActivity
import com.example.mkshop.R
import com.example.mkshop.detail.*

class CookiesList : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cookies)

        //detail btn
        val almondCookiesDetailBtn : Button = findViewById(R.id.almond_cookies_detail)
        val chocolateCookiesDetailBtn : Button = findViewById(R.id.chocolate_cookies_detail)
        val strawberryCookiesDetailBtn : Button = findViewById(R.id.strawberry_cookies_detail)
        val backToHomeBtn: Button = findViewById(R.id.back_to_home)

        //detail button onclick listener
        almondCookiesDetailBtn.setOnClickListener(){goToCookiesDetail(almondCookiesDetailBtn)}
        chocolateCookiesDetailBtn.setOnClickListener(){goToCookiesDetail(chocolateCookiesDetailBtn)}
        strawberryCookiesDetailBtn.setOnClickListener(){goToCookiesDetail(strawberryCookiesDetailBtn)}
        backToHomeBtn.setOnClickListener(){goToHome(backToHomeBtn)}
    }

    fun goToCookiesDetail(v: View) {
        when (v.id) {
            R.id.almond_cookies_detail -> {
                val almondCookiesDetailIntent = Intent(this@CookiesList, AlmondCookiesDetail::class.java)
                startActivity(almondCookiesDetailIntent)
            }
            R.id.chocolate_cookies_detail -> {
                val chocolateCookiesDetailIntent = Intent(this@CookiesList, ChocolateCookiesDetail::class.java)
                startActivity(chocolateCookiesDetailIntent)
            }
            R.id.strawberry_cookies_detail -> {
                val strawberryCookiesDetail = Intent(this@CookiesList, StrawberryCookiesDetail::class.java)
                startActivity(strawberryCookiesDetail)
            }

        }
    }
    private fun goToHome(v: View) {
        when (v.id) {
            R.id.back_to_home -> {
                val backToHomeIntent = Intent(this@CookiesList, MainActivity::class.java)
                startActivity(backToHomeIntent)
            }
        }
    }
}