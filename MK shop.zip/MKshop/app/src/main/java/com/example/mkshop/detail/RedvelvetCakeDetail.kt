package com.example.mkshop.detail

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.checkout.CheckoutCake
import com.example.mkshop.R

class RedvelvetCakeDetail : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cake_item_redvelvet)

        val buyNow : Button = findViewById(R.id.buy_now)
        buyNow.setOnClickListener(){goToBayar(buyNow)}
    }

    private fun goToBayar(v: View) {
        when (v.id) {
            R.id.buy_now -> {
                val checkoutCakeIntent = Intent(this@RedvelvetCakeDetail, CheckoutCake::class.java)
                startActivity(checkoutCakeIntent)
            }
        }
    }
}