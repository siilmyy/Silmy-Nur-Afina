package com.example.mkshop.foodList

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.MainActivity
import com.example.mkshop.R
import com.example.mkshop.detail.CaramelCakeDetail
import com.example.mkshop.detail.ChocolateCakeDetail
import com.example.mkshop.detail.OreoCakeDetail
import com.example.mkshop.detail.RedvelvetCakeDetail

class CakeList : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cakes_list)

        //detail btn
        val chocolateCakeDetailBtn : Button = findViewById(R.id.chocolate_cake_detail)
        val caramelCakeDetailBtn : Button = findViewById(R.id.caramel_cake_detail)
        val redvelvetDetailBtn : Button = findViewById(R.id.redvelvet_cake_detail)
        val oreoCakeDetailBtn : Button = findViewById(R.id.oreo_cake_detail)
        val backToHomeBtn: Button = findViewById(R.id.back_to_home)

        //detail button onclick listener
        chocolateCakeDetailBtn.setOnClickListener(){ goToCakeDetail(chocolateCakeDetailBtn)}
        caramelCakeDetailBtn.setOnClickListener(){ goToCakeDetail(caramelCakeDetailBtn)}
        redvelvetDetailBtn.setOnClickListener(){ goToCakeDetail(redvelvetDetailBtn)}
        oreoCakeDetailBtn.setOnClickListener(){ goToCakeDetail(oreoCakeDetailBtn)}
        backToHomeBtn.setOnClickListener(){goToHome(backToHomeBtn)}


    }
    fun goToCakeDetail(v: View) {
        when (v.id) {
            R.id.chocolate_cake_detail -> {
                val chocolateCakeDetailIntent = Intent(this@CakeList, ChocolateCakeDetail::class.java)
                startActivity(chocolateCakeDetailIntent)
            }
            R.id.caramel_cake_detail -> {
                val caramelCakeDetailIntent = Intent(this@CakeList, CaramelCakeDetail::class.java)
                startActivity(caramelCakeDetailIntent)
            }
            R.id.redvelvet_cake_detail -> {
                val redvelvetCakeDetail = Intent(this@CakeList, RedvelvetCakeDetail::class.java)
                startActivity(redvelvetCakeDetail)
            }
            R.id.oreo_cake_detail -> {
                val oreoCakeDetailIntent = Intent(this@CakeList, OreoCakeDetail::class.java)
                startActivity(oreoCakeDetailIntent)
            }

        }
    }

    private fun goToHome(v: View) {
        when (v.id) {
            R.id.back_to_home -> {
                val backToHomeIntent = Intent(this@CakeList, MainActivity::class.java)
                startActivity(backToHomeIntent)
            }
        }
    }


}