package com.example.mkshop.checkout

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.mkshop.MainActivity
import com.example.mkshop.R

class CheckoutVerified : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.verified_checkout)

        val backToHomeBtn: Button = findViewById(R.id.back_to_home)
        backToHomeBtn.setOnClickListener(){goToHome(backToHomeBtn)}
    }
    private fun goToHome(v: View) {
        when (v.id) {
            R.id.back_to_home -> {
                val backToHomeIntent = Intent(this@CheckoutVerified, MainActivity::class.java)
                startActivity(backToHomeIntent)
            }
        }
    }

}